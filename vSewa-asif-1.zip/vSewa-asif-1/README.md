# vSewa
### An ANDROID application using FIREBASE for Database Management, Authentication, Storage

## Objective
Our objective is to provide help locally to old age people, PWD, needy by connecting with
people who want to volunteer, through the app and NGOs and increase awareness in people.

