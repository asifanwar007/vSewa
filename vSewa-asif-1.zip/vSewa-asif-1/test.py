print("this changes is for testing pruposes")
print("hello world")
print("Ye kya chal rha hai!")
print("merge request pull")
def helo(name):
	print("hello" + name)
name=input()

print("abslan change ")
helo(name)

# if __name__ == '__main__':
	# helo(name)


print("Hello world")
print("This file suxx")

print("maa ka")



